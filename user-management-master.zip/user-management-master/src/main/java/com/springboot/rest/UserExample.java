package com.springboot.rest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserExample {

	public static void main(String[] args) {
		SpringApplication.run(UserExample.class, args);
	}
}
